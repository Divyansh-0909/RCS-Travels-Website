import {closureCoreScope} from './closure-scope.mjs';
export default {
  testRunner:'command',coverageAnalysis:'off',tsconfigFile:'backend/tests/quality/phase6b-no-tsconfig.json',
  commandRunner:{command:'node --test --test-concurrency=1 backend/tests/phase9dCustodyClosure.test.js backend/tests/phase9dCustodyClosureTransport.test.js backend/tests/phase9dCustodyObserver.test.js'},
  mutate:closureCoreScope,
  ignorePatterns:['**/node_modules/**','**/.env','**/.env.*','.*','**/.*','output','docs','plugins','decisions','ds-bundle','legal-review','screenshots','search_assignment','temporary screenshots','test-results','tmp','backend/{coverage,uploads,rcs-rag}','frontend/{dist,public}','driver-app/{android,ios}','founder'],
  reporters:['clear-text','json'],jsonReporter:{fileName:'output/phase9d-custody-closure-2026-10-15/mutation-core-initial.json'},
  concurrency:2,timeoutMS:12000,timeoutFactor:2,cleanTempDir:false,
};
